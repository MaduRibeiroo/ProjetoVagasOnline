package fipp.ariane.vagasonlinebe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VagasonlinebeApplication {

	public static void main(String[] args) {
		SpringApplication.run(VagasonlinebeApplication.class, args);
	}

}
